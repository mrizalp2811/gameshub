import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Header from './component/Header';
import * as serviceWorker from './serviceWorker';


const headerContent = { 
	img: hbg,
	imgClass: 'home-bg' ,
	text: 'EASY WORLDWIDE STRENGTHEN YOUR GAMES',
	textClass: 'h-text',
	smText: 'Manage your games business on network and monetization via our games business platform.',
	smTextClass: 'h-smText'
};

ReactDOM.render(
    <Header content={headerContent}/>,
  	document.getElementById('haha')
);



// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
