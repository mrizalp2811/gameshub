import React from 'react';
import './App.css';
import Home from './pages/Home'
import About from './pages/About';
import Shop from './pages/Shop';
import GI from './pages/Game-infrastructure';
import MpE from './pages/Multiplayer-engine';
import GmI from './pages/Game-intelligence';
import Monetize from './pages/Monetization';

import {BrowserRouter as Router, Switch, Route} from 'react-router-dom';
function App() {
  return (
    <Router>
      <div>
        <Switch>
          <Route path="/" exact component={Home}/>
          <Route path="/home" exact component={Home}/>
          <Route path="/about" component={About}/>
          <Route path="/shop" component={Shop}/>
          <Route path="/game-infrastructure" component={GI}/>
          <Route path="/multiplayer-engine" component={MpE}/>
          <Route path="/game-intelligence" component={GmI}/>
          <Route path="/monetization" component={Monetize}/>
        </Switch>
      </div>
    </Router>
  );
}
export default App;
