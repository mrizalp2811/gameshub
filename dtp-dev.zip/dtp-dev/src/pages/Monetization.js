/* eslint-disable jsx-a11y/anchor-has-content */
/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react';
import Header from '../component/Header';
// import hbg from '../component/img/icons/console.svg';
import MIcon from '../component/Monetize-icon.js';
import Footer from '../component/footer';

import bni from '../component/img/icons/bni.png';
import dana from '../component/img/icons/dana.png';
import danamon from '../component/img/icons/danamon.png';
import gopay from '../component/img/icons/gopay.png';
import tri from '../component/img/icons/3.png';
import linkaja from '../component/img/icons/linkaja.png';
import ovo from '../component/img/icons/ovo.png';
import sakuku from '../component/img/icons/sakuku.png';
import smartfren from '../component/img/icons/smartfren.png';
import telkomsel from '../component/img/icons/telkomsel.png';
import xl from '../component/img/icons/xl.png';


function monetization() {
    const headerContent = { 
        img: <MIcon/>,
        imgClass: 'h-svg',
        text: 'Monetization Channel',
        textClass: 'h-text-2',
        smText: 'Empower your games business with our local Indonesian payment gateway and one-time store distribution channel.',
        smTextClass: 'h-smText-2'
    };
    return (
        <div>
            <section id="header" className="hbg"><Header content={headerContent}/></section>
            <section className="bg-2 common-2 row">
                <div className="col-md-6">
                    <h4 className="c-purple">Better Monetization</h4>
                    <span>We will help your games monetization better by giving an easy way to accept local Indonesian Market Payment.</span>
                </div>
                <div className="col-md-6 text-center">
                    <h4>&nbsp;</h4>
                    <a className="btn btn-primary mx-0">Contact Us</a>
                </div>
                </section>
            <section className="row">
                <div className="col-md-6">
                    <h4 className="c-purple">Payment Option</h4>
                    <span>
                        Unlocks connections to telcos, banks, e-wallets, cash at retail, and vouchers in Indonesia
                    </span>
                    <ul className="list-img-arrow-right c-purple-dark pt-3">
                        <li>Simple Integration</li>
                        <li>Reliable Platform</li>
                        <li>24/7 Support</li>
                    </ul>
                    <p><a className="more" href="#!">Explore Api</a> <span className="c-purple-dark"> Or </span> <a className="more" href="#!">Explore Api</a></p>
                </div>
                <div className="col-md-6">
                    <table width="100%" className="pt-5">
                        <tbody>
                            <tr>
                                <td width="50%" className="text-center">
                                    <a href="#!"><img className="r-bnw" src={linkaja} alt="LinkAja"/></a>
                                </td>
                                <td width="50%" className="text-center">
                                    <a href="#!"><img className="r-bnw" src={telkomsel} alt="Telkomsel"/></a>
                                </td>
                            </tr>
                            <tr>
                                <td width="50%" className="text-center">
                                    <a href="#!"><img className="r-bnw" src={dana} alt="Dana"/></a>
                                </td>
                                <td width="50%" className="text-center">
                                    <a href="#!"><img className="r-bnw" src={tri} alt="Tri"/></a>
                                </td>
                            </tr>
                            <tr>
                                <td width="50%" className="text-center">
                                    <a href="#!"><img className="r-bnw" src={gopay} alt="Go-Pay"/></a>
                                </td>
                                <td width="50%" className="text-center">
                                    <a href="#!"><img className="r-bnw" src={ovo} alt="Ovo"/></a>
                                </td>
                            </tr>
                            <tr>
                                <td width="50%" className="text-center">
                                    <a href="#!"><img className="r-bnw" src={sakuku} alt="Sakuku"/></a>
                                </td>
                                <td width="50%" className="text-center">
                                    <a href="#!"><img className="r-bnw" src={xl} alt="XL"/></a>
                                </td>
                            </tr>
                            <tr>
                                <td width="50%" className="text-center">
                                    <a href="#!"><img className="r-bnw" src={smartfren} alt="Smartfren"/></a>
                                </td>
                                <td width="50%" className="text-center">
                                    <a href="#!"><img className="r-bnw" src={bni} alt="BNI"/></a>
                                </td>
                            </tr>
                            <tr>
                                <td width="50%" className="text-center">
                                    <a href="#!"><img className="r-bnw" src={danamon} alt="Danamon"/></a>
                                </td>
                                <td width="50%" className="text-center">
                                    <p className="more"><a className="more">See more...</a></p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div className="col-md-12 pt-5">
                    <hr/>
                </div>
                <div className="col-md-12">
                    <h4 className="c-purple my-4">Distribution</h4>
                </div>
                <div className="col-md-6 py-3">
                    <span>Sell and add benefit for your in-game voucher through our distribution channel.</span>
                    <p><a className="more" href="#!">Explore Api</a></p>
                </div>
                <div className="col-md-6">
                    <ul className="list-img-arrow-right c-purple-dark pt-3">
                        <li>Simple Integration</li>
                        <li>Reliable Platform</li>
                        <li>24/7 Support</li>
                    </ul>
                </div>
            </section>
            <section id="footer"><Footer/></section>
        </div>
    );
}

export default monetization;
