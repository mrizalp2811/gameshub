import React from 'react';
import Header from '../component/Header';
// import hbg from '../component/img/icons/console.svg';
import MEIcon from '../component/ME-icon.js';
import Footer from '../component/footer';

function multiplayer_engine() {
    const headerContent = { 
        img: <MEIcon/>,
        imgClass: 'h-svg',
        text: 'Multiplayer Engine',
        textClass: 'h-text-2',
        smText: 'Game sessions are spread out over multiple providers to ensure redundancy and to achieve the best possible coverage in every region of the world.',
        smTextClass: 'h-smText-2'
    };
    return (
        <div>
            <section id="header" className="hbg"><Header content={headerContent}/></section>
            <section id="footer"><Footer/></section>
        </div>
    );
}

export default multiplayer_engine;
