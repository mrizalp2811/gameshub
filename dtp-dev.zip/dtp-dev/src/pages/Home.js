import React from 'react';
import Header from '../component/Header';
import Mission from '../component/Mission';
import Customers from '../component/Customer';
import Footer from '../component/footer';
import {IGraph, IPrize, ICalendar} from '../component/icons';

import hbg from '../component/img/h-object.png';

import garena from '../component/img/customer/garena.png';
import gamescool from '../component/img/customer/gamescool.png';
import zepetto from '../component/img/customer/zepetto.png';
import lyto from '../component/img/customer/lyto.png';
import anantarupa from '../component/img/customer/anantarupa.png';

function Home() {
    const headerContent = { 
        img: hbg,
        imgClass: 'home-bg' ,
        text: 'EASY WORLDWIDE STRENGTHEN YOUR GAMES',
        textClass: 'h-text',
        smText: 'Manage your games business on network and monetization via our games business platform.',
        smTextClass: 'h-smText'
    };
    const missionContent = { 
        title: "OUR MISSION",
        content: "Our agnostic approach to game server infrastructure enables servers resources to evolve according to player demand and as features & content are released.",
    };
    const customers = {
        title: "OUR CUSTOMER",
        logos: [garena,gamescool,zepetto, lyto, anantarupa],
        class: ['cs-logo-item','cs-logo-item','cs-logo-item sm-12','cs-logo-item','cs-logo-item']
    }
    return (
        <div>
            <section id="header" className="hbg-2"><Header content={headerContent}/></section>
            <section id="mission"><Mission content={missionContent}/></section>
            <section id="customer"><Customers content={customers}/></section>
            <section id="gh-network" className="bg-2 common-2 my-5">
                <div className="bg-net row" id="bg-net">
                    <div className="col-md-6 g-content">
                        Games Infrastructure
                        <p>Understanding where a game falls within the latency-sensitivity spectrum is a key component of infrastructure planning</p>
                        <a href="#!">Read more...</a>
                    </div>
                    <div className="col-md-6 g-space">&nbsp;</div>
                    <div className="col-md-6 g-space">&nbsp;</div>
                    <div className="col-md-6 g-content">
                        Multiplayer Engine
                        <p>Game sessions are spread out over multiple providers to ensure redundancy and to achieve the best possible coverage in every region of the world.</p>
                        <a href="#!">Read more...</a>
                    </div>
                    <div className="col-md-6 g-content">
                        Monetization Channel
                        <p>Empower your games business with our local Indonesian payment gateway and one-time store distribution channel.</p>
                        <a href="#!">Read more...</a>
                    </div>
                    <div className="col-md-6 g-space">&nbsp;</div>
                    <div className="col-md-6 g-space">&nbsp;</div>
                    <div className="col-md-6 g-content">
                        Games Intelligence
                        <p>Game sessions are spread out over multiple providers to ensure redundancy and to achieve the best possible coverage in every region of the world.</p>
                        <a href="#!">Read more...</a>
                    </div>
                    <div className="col-md-6">
                    </div>
                </div>
            </section>
            <section className="common-2 row">
                <div className="col-lg-6 pl-0 pt-0">
                    <div className="s-content pl-0 pr-0">
                        <p>The GAMESHUB SOLUTION</p>
                        Cost-effective Time saving High quality
                    </div>
                </div>
                <div className="accent">
                    <div className="accent-icon bg-3"><IGraph/></div>
                    <div className="accent-content bg-3">
                        Cost-effective
                        <p>Game sessions are spread out over multiple providers to ensure redundancy and to achieve the best possible coverage in every region of the world.</p>
                    </div>
                </div>
                <div className="accent">
                    <div className="accent-icon bg-4"><ICalendar/></div>
                    <div className="accent-content bg-4">
                        Time Saved
                        <p>Game sessions are spread out over multiple providers to ensure redundancy and to achieve the best possible coverage in every region of the world.</p>
                    </div>
                </div>
                <div className="accent">
                    <div className="accent-icon bg-5"><IPrize/></div>
                    <div className="accent-content bg-5">
                        Higher-quality
                        <p>Game sessions are spread out over multiple providers to ensure redundancy and to achieve the best possible coverage in every region of the world.</p>
                    </div>
                </div>
                <div className="contact-us"></div>
            </section>
            <section id="for-gamer" className="bg-6 mb-5">
                <div className="gamer">
                    FOR THE GAMERS
                    <p>
                        Competitive, action-packed multiplayer games require a lot of computing power and low latency server locations to run smoothly. Gameye ensures a quality gaming experience for every player by providing high-performance session hosting for game developers - even in upcoming and hard to reach locations around the world.
                    </p>
                </div>
	        </section>
            <section id="footer"><Footer/></section>
        </div>
    );
}

export default Home;
