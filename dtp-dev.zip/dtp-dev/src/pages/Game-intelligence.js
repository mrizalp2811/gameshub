import React from 'react';
import Header from '../component/Header';
// import hbg from '../component/img/icons/console.svg';
import GameIntelligenceIcon from '../component/GIntelligence-icon';
import Footer from '../component/footer';

function game_intelligence() {
    const headerContent = { 
        img: <GameIntelligenceIcon/>,
        imgClass: 'h-svg',
        text: 'Games Intelligence',
        textClass: 'h-text-2',
        smText: 'Game sessions are spread out over multiple providers to ensure redundancy and to achieve the best possible coverage in every region of the world.',
        smTextClass: 'h-smText-2'
    };
    return (
        <div>
            <section id="header" className="hbg"><Header content={headerContent}/></section>
            <section id="footer"><Footer/></section>
        </div>
    );
}

export default game_intelligence;
