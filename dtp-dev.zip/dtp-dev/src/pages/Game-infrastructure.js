/* eslint-disable jsx-a11y/anchor-has-content */
/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react';
import Header from '../component/Header';
import NetWork from '../component/Network-service';
import GIIcon from '../component/GI-icon';
import Cloud from '../component/Cloud-service'
import Customers from '../component/Customer';
import Footer from '../component/footer';


import garena from '../component/img/customer/garena.png';
import gamescool from '../component/img/customer/gamescool.png';
import zepetto from '../component/img/customer/zepetto.png';
import lyto from '../component/img/customer/lyto.png';
import anantarupa from '../component/img/customer/anantarupa.png';

const headerContent = { 
    img: <GIIcon/>,
    imgClass: 'h-svg',
    text: 'Games Infrastructure',
    textClass: 'h-text-2',
    smText: 'Understanding where a game falls within the latency-sensitivity spectrum is a key component of infrastructure planning',
    smTextClass: 'h-smText-2'
};



class Infrastructure extends React.Component{
    constructor() {
        super()
    
        this.state = {
          activeItem: 0,
          items: ['Network Service', 'Cloud Service'],
          itemsContent: [<NetWork/>, <Cloud/>],
        }
      }
    
    handleItemClick(index) {
        this.setState({
            activeItem: index,
        });
    }
    
    render(){
        const customers = {
            title: "OUR CUSTOMER",
            logos: [garena,gamescool,zepetto, lyto, anantarupa],
            class: ['cs-logo-item','cs-logo-item','cs-logo-item sm-12','cs-logo-item','cs-logo-item']
        }
        return (
            <div>
                <section id="header" className="hbg"><Header content={headerContent}/></section>
                <section className="bg-2 common-2 row">
                    <div className="col-md-12">
                        <ul className="gi-list">
                            {this.state.items.map((item, index) =>
                                <li
                                key={index}
                                className={this.state.activeItem === index ? 'active' : ''}
                                onClick={this.handleItemClick.bind(this, index)}
                                >
                                {item}
                                </li>
                            )}
                        </ul>
                    </div>
                    {
                        this.state.itemsContent[this.state.activeItem]
                    }
                </section>
                <section id="customer"><Customers content={customers}/></section>
                <section id="footer"><Footer/></section>
            </div>
        );
    }
}

export default Infrastructure;
