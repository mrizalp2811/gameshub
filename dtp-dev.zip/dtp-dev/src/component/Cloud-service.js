/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable jsx-a11y/anchor-has-content */
/* eslint-disable jsx-a11y/anchor-is-valid */

import React, { Component } from 'react';
import ImgBg from './img/right-antimage.png';
import IServer from './img/icons/server.png';
import IMonitor from './img/icons/monitor.png';
import IMoney from './img/icons/money.png';
import IDownload from './img/icons/download.png';

class Cloud extends Component{
    render(){
        return (
            <div className="row">
                <div className="col-md-6">
                    <h4 className="title">Game Server Hosting</h4>
                    <div className="text-justify">
                        <span>
                            Deploys your game servers onto running instances, load-balances traffic across fleets of game servers, monitors instance and game server health, and replaces unhealthy instances without your intervention.
                        </span>
                    </div>
                </div>
                <div className="col-md-6 pt-5">
                    <ul className="list-img-arrow-right">
                        <li><span>Dedicated Game Server Hosting</span></li>
                        <li><span>Server Management Platform</span></li>
                        <li><span>24/7 Monitoring and DDoS Protection</span></li>
                    </ul>
                </div>
                <div className="col-md-12 py-2">
                    <hr/>
                </div>
                <div className="col-md-12 py-5 row">
                    <div className="col-md-6 px-0 row pb-5">
                        <div className="col-sm-3 text-center">
                            <img className="icon" src={IServer}/>
                        </div>
                        <div className="col-sm-9 text-sm-center">Automatically scale server capacity with player traffic</div>
                    </div>
                    <div className="col-md-6 px-0 row pb-5">
                        <div className="col-sm-3 text-center">
                            <img className="icon" src={IMonitor}/>
                        </div>
                        <div className="col-sm-9 text-sm-center">Connect your community across devices and broaden your pool of players for potential matches</div>
                    </div>
                    <div className="col-md-6 px-0 row pb-5">
                        <div className="col-sm-3 text-center">
                            <img className="icon" src={IMoney}/>
                        </div>
                        <div className="col-sm-9 text-sm-center">Save costs and keep availability high</div>
                    </div>
                    <div className="col-md-6 px-0 row pb-5">
                        <div className="col-sm-3 text-center">
                            <img className="icon" src={IDownload}/>
                        </div>
                        <div className="col-sm-9 text-sm-center">No downtime for updates</div>
                    </div>
                </div>
                <div className="col-md-12 text-center">
                    <a className="btn btn-primary btn-mr-0">Contact Us</a>
                    <img className="absolute-right-bottom-img" src={ImgBg}/>
                </div>
            </div>
        );
    }
}

export default Cloud;