/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable no-undef */
/* eslint-disable jsx-a11y/anchor-has-content */
/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react';
import logo from './img/logo.svg';
import './haeder.css';


class Header extends React.Component{
	constructor(content) {
		super(content);
		this.state = {content};
	}
	render(){
		const inner = this.state.content.content;
		if (inner.imgClass == "home-bg") {
			return(
				<div className="header">
						<img src={logo} className="left-logo" alt="logo" />
						<div className="group-right">
							<span>LET'S TALK GAMES</span>
							<a href="#" className="btn ">Contact Us</a>
							<div className="right-menu">
								<ul>
									<li><a href="/">Home</a></li>
									<li>
										<a href="#">Service</a>
										<ul>
											<li><a href="/game-infrastructure">Games Infrastructure</a></li>
											<li><a href="/multiplayer-engine">Multiplayer Engine</a></li>
											<li><a href="/monetization">Monetization</a></li>
											<li><a href="/game-intelligence">Games Intelligence</a></li>
										</ul>
									</li>
									<li><a href="#">Blog</a></li>
								</ul>
							</div>
						</div>
					<div className="header-content">
						<div className={inner.textClass}>{inner.text}</div>
						<div className={inner.smTextClass}>{inner.smText}
							<div className="contact-us-btn-group">
								<h3>LET'S TALK ABOUT GAMES</h3>
								<a className="btn" href="#">Contact Us</a>
							</div>
						</div>
						<img src={inner.img} className={inner.imgClass}/>
					</div>
				</div>
			);
		}
		else{
			return(
				<div className="header">
					
						<img src={logo} className="left-logo" alt="logo" />
						<div className="group-right">
							<span>LET'S TALK GAMES</span>
							<a href="#" className="btn ">Contact Us</a>
							<div className="right-menu mr-0">
								<ul>
									<li><a href="/">Home</a></li>
									<li>
										<a href="#">Service</a>
										<ul>
											<li><a href="/game-infrastructure">Games Infrastructure</a></li>
											<li><a href="/multiplayer-engine">Multiplayer Engine</a></li>
											<li><a href="/monetization">Monetization</a></li>
											<li><a href="/game-intelligence">Games Intelligence</a></li>
										</ul>
									</li>
									<li><a href="#">Blog</a></li>
								</ul>
							</div>
						</div>
					
					<div className="header-content row col-lg-7">
						<div className={inner.textClass}>{inner.text}</div>
						<div className={inner.imgClass}>{inner.img}</div>
						<div className={inner.smTextClass}>{inner.smText}
							<div className="contact-us-btn-group">
								<h3>LET'S TALK ABOUT GAMES</h3>
								<a className="btn" href="#">Contact Us</a>
							</div>
						</div>
						
					</div>
				</div>
			);
		}
		
	}
}

export default Header;
