import React from 'react';
import ReactDOM from 'react-dom';

class Gamer extends React.Component{
    render(){
        return(
            <div className="gamer">
                FOR THE GAMERS
                <p>
                    Competitive, action-packed multiplayer games require a lot of computing power and low latency server locations to run smoothly. Gameye ensures a quality gaming experience for every player by providing high-performance session hosting for game developers - even in upcoming and hard to reach locations around the world.
                </p>
            </div>
        );
    }
}

ReactDOM.render(
    <Gamer />,
    document.getElementById('for-gamer')
);