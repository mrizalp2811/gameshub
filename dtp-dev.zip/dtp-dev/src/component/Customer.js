/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable no-undef */
/* eslint-disable jsx-a11y/anchor-has-content */
/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react';
import './Customer.css';


class Customer extends React.Component{
	constructor(content) {
		super(content);
        this.state = {content};
        
    }
    
	render(){
        const inner = this.state.content.content;
		return(
            <div className="customer row">
                <div className="col-md-12">
                    <div className="customerTitle">{inner.title}</div>
                    <div className="line-breaker"></div>
                    <div className="cs-logo">
                        {inner.logos.map(function(name, index){
                            return <div className={inner.class[index]} href="#" key={index}>
                                <a><img src={name} key={ index }/></a>
                            </div>;
                        })}
                    </div>
                    <div className="line-breaker"></div>
                    <div className="group-right">
						<span>LET'S TALK GAMES</span>
						<a href="#" className="btn ">Contact Us</a>
                    </div>
                </div>
            </div>
        );
	}
}

export default Customer;
