/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react';
import ReactDOM from 'react-dom';
class Contact extends React.Component{
    render(){
        return(
            <div className="group-right">
                <span>LET'S TALK GAMES</span>
                <a href="#" className="btn">Contact Us</a>
            </div>
            
        );
    }
}

for (let i = 0; i < document.getElementsByClassName('contact-us').length; i++) {
    ReactDOM.render(
        <Contact />,
        document.getElementsByClassName('contact-us')[i]
    )
}