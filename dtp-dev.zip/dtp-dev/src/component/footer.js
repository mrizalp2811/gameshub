/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react';
import './footer.css';
import {IFacebook, ITwitter, IInstagram, ILogo} from './icons';

class Footer extends React.Component{
    render(){
        return(
            <div >
                <div id="h-footer" className="h-footer">
                    <div className="h-footer-inner">
                        <div>
                            <p>BRINGING</p>
                            THE SERVER CLOSER TO THE PLAYER
                        </div>
                    </div>
                    <div className="line-breaker-y"> </div>
                </div>
                <div id="c-footer" className="c-footer-container">
                    <div className="c-footer-inner row">
                        <div className="col-md-8">
                            <h1>LET'S TALK GAMES</h1>
                            Our agnostic approach to game server infrastructure enables servers resources to evolve according to player demand and as features & content are released.
                        </div>
                        <div className="col-md-4">
                            <div className="btn-right">
                                <a href="#" className="btn btn-primary btn-mr-0 btn-block">CONTACT US</a>
                                <a href="#" className="btn btn-info btn-mr-0 btn-block">JOIN DISCORD</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="b-footer">
                    <div className="b-footer">
                        <div className="b-footer-txt">
                            <h4>GamesHub</h4>
                            Menara Bandung Digital Valley, Jl. Gegerkalong Hilir No.47, Sukarasa, Kec. Sukasari, Kota Bandung, Jawa Barat 40152
                        </div>
                        <div className="b-footer-right">
                            <a href="#"><ITwitter/></a>
                            <a href="#"><IFacebook/></a>
                            <a href="#"><IInstagram/></a>
                            <div>
                                <a href="#"><ILogo/></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default Footer;