/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable jsx-a11y/anchor-has-content */
/* eslint-disable jsx-a11y/anchor-is-valid */

import React, { Component } from 'react';
import ImgBg from './img/minecraft.png';

class NetWork extends Component{
    render(){
        return (
            <div className="row">
                <div className="col-md-6">
                    <h4 className="title">IP Transit</h4>
                    <div className="text-justify">
                        <span>
                            Service for customer networks that are independant and has a customer’s internet resources (IP Address Portable version 4 or version 6), ASN- Autonomous System Number), has its own internet networking support (consist of and not limited to DNS and Mail Relay).
                            <p><a className="more">See more...</a></p>
                        </span>
                    </div>
                </div>
                <div className="col-md-6 pt-5">
                    <ul className="list-img-arrow-right">
                        <li><span>Full SLA 99% Network Availability</span></li>
                        <li><span>Bandwidth Guarantee 1-1 Reference Point</span></li>
                        <li><span>Full Route BGP Internet Global and/or Domestic Prefix</span></li>
                    </ul>
                </div>
                <div className="col-md-12 py-2">
                    <hr/>
                </div>
                <div className="col-md-12 row">
                    <div className="col-md-6"></div>
                    <div className="col-md-6">
                        <h4 className="title">Network Peering</h4>
                    </div>
                </div>
                <div className="col-md-6">
                    <ul className="list-img-arrow-right">
                        <li><span>Low latency high-speed internet connectivity</span></li>
                        <li><span>Online peering and traffic management tools</span></li>
                        <li><span>Improved performances with direct paths to destination networks</span></li>
                    </ul>
                </div>
                <div className="col-md-6">
                    Private peering to access Telkom’s Eyeballs with high quality service.
                    <p><a className="more">See more...</a></p>
                </div>
                <div className="col-md-12">
                    <hr/>
                </div>
                <div className="col-md-12 row">
                    <div className="col-md-6 px-0"><h4 className="title">CDN</h4></div>
                    <div className="col-md-6"></div>
                </div>
                <div className="col-md-6">
                    <span>
                        Optimize your games internet experience by using our globally distributed server platform.
                        <p><a className="more">See more...</a></p>
                    </span>
                </div>
                <div className="col-md-6">
                    <span>
                        Optimize your games internet experience by using our globally distributed server platform.
                        <p><a className="more">See more...</a></p>
                    </span>
                </div>
                <div>
                    <ul className="list-img-arrow-right">
                        <li><span>Widest Coverage in Indonesia</span></li>
                        <li><span>Multi CDS, Multi Solution</span></li>
                        <li><span>24x7 Local Support</span></li>
                    </ul>
                </div>
                <div className="col-md-12 text-center">
                    <a className="btn btn-primary btn-mr-0">Contact Us</a>
                    <img className="absolute-right-bottom-img" src={ImgBg}/>
                </div>
            </div>
        );
    }
}

export default NetWork;