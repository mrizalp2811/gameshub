/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable no-undef */
/* eslint-disable jsx-a11y/anchor-has-content */
/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react';
import './Mission.css';


class Mission extends React.Component{
	constructor(content) {
		super(content);
        this.state = {content};
    }
    
	render(){
        const inner = this.state.content.content;
		return(
            <div className="missions row">
                <div className="col-md-8">
                    <div className='missionTitle' > {inner.title} </div>
                    <div className='missionContent'> {inner.content}</div>
                </div>
            </div>
        );
	}
}

export default Mission;
